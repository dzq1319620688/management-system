import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Layout',
    component: ()=>import("../views/Layout"),
    redirect:'/index',
    children:[
      {
        path:'/index',
        name:'Index',
        component:()=>import('../views/index/Index.vue'),
        meta:{bread:['首页']}
      },
      {
        path:'/account/all',
        name:'acconut_all',
        component:()=>import('../views/account/All.vue'),
        meta:{bread:['账户管理','所有人员']}
      },
      {
        path:'/product/all',
        name:'product_all',
        component:()=>import('../views/product/All.vue'),
        meta:{bread:['产品管理','所有产品']}
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
