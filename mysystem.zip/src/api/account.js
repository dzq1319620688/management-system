import service from '@/router/service'

// 
export const accountAll= (data) => {
  return service({
    url: '/account/all',
    method: 'get',
    data
  })
}