// import { of } from "core-js/core/array";
import Mock from "mockjs";
//登录接口
Mock.mock("localhost:8080/login", "post", (req) => {
    const {
        username,
        password
    } = JSON.parse(req.body);
    if (username == 'dzq' && password == 123456) {
        return {
            code: 200,
            success: true,
            nickname: '董志强',
            token: '31hgfhgf45hjghf4',
            message: '登录成功'
        }
    } else {
        return {
            code: 100,
            success: false,
            message: '账号或者密码有误'
        }
    }
})

// 记录入职时间接口
Mock.mock('localhost:8080/in', 'get', () => {
    return {
        code: 200,
        success: true,
        message: '操作成功',
        time: '2021-10-10 00:00:00'
    }
})

//左侧菜单数据
const menuList1 = [
    {
        name: "账户管理",
        icon: "el-icon-coin",
        url: "/account",
        children: [{
                name: "所有人员",
                icon: "el-icon-user",
                url: "/account/all",
                meta:{bread:['账户管理','所有人员']}
            },
            {
                name: "业务人员",
                icon: "el-icon-phone-outline",
                url: "/account/business",
            },
            {
                name: "审核人员",
                icon: "el-icon-s-check",
                url: "/account/audit",
            },
            {
                name: "风控经理",
                icon: "el-icon-s-finance",
                url: "/account/risk",
            },
            {
                name: "管理员",
                icon: "el-icon-s-custom",
                url: "/account/admin",
            }
        ]
    },
    {
        name: "产品管理",
        icon: "el-icon-menu",
        url: "/product",
        children: [{
                name: "全部产品",
                icon: "el-icon-notebook-2",
                url: "/product/all",
                meta:{bread:['产品管理','所有产品']}
            },
            {
                name: "汽车消费",
                icon: "el-icon-truck",
                url: "/product/carConsumption",
            },
            {
                name: "房产消费",
                icon: "el-icon-office-building",
                url: "/product/estate",
            },
            {
                name: "抵押贷款",
                icon: "el-icon-money",
                url: "/product/mortgage",
            },
        ]
    },
    {
        name: "客户管理",
        icon: "el-icon-user",
        url: "/customer",
        children: [{
                name: "基本信息",
                icon: "el-icon-chat-square",
                url: "/customer/info",
            },
            {
                name: "资金记录",
                icon: "el-icon-bank-card",
                url: "/record",
            },
        ]
    },
    {
        name: "个人中心",
        icon: "el-icon-user",
        url: "/my",
    }
]
const menuList2 = [
{
    name: "产品管理",
    icon: "el-icon-menu",
    url: "/product",
    children: [{
            name: "全部产品",
            icon: "el-icon-notebook-2",
            url: "/product/all",
            meta:{bread:['产品管理','所有产品']}
        },
        {
            name: "汽车消费",
            icon: "el-icon-truck",
            url: "/product/carConsumption",
        },
        {
            name: "房产消费",
            icon: "el-icon-office-building",
            url: "/product/estate",
        },
        {
            name: "抵押贷款",
            icon: "el-icon-money",
            url: "/product/mortgage",
        },
    ]
},
{
    name: "客户管理",
    icon: "el-icon-user",
    url: "/customer",
    children: [{
            name: "基本信息",
            icon: "el-icon-chat-square",
            url: "/customer/info",
        },
        {
            name: "资金记录",
            icon: "el-icon-bank-card",
            url: "/record",
        },
    ]
},
{
    name: "个人中心",
    icon: "el-icon-user",
    url: "/my",
}
]
//左侧菜单接口
Mock.mock(RegExp('localhost:8080/menu' + '.*'), 'get', (req) => {
    let paramsData=JSON.parse(req.body)
    if(paramsData.type==1){
        return {
            code: 200,
            success: true,
            message: "成功",
            data: menuList1
        }
    }else if(paramsData.type==2){
        return{
            code: 200,
            success: true,
            message: "成功",
            data: menuList2
        }
    }
});

//图表
Mock.mock('localhost:8080/load', 'post', () => {
    return {
        code: 200,
        success: true,
        message: "成功",
        data: {
            xdata: ['20.01', '20.02', '20.03', '20.04', '20.05', '20.06', '20.07'],
            ydata: [25, 80, 60, 50, 60, 30, 20]
        }
    }
});

//所有人员
Mock.mock(RegExp('localhost:8080/account/all' + '.*'), 'get', options => {
    let paramsData= options.url.split("?")[1].split("&")
    let params={}
    for(let i=0;i<paramsData.length;i++){
        let arr = paramsData[i].split("=")
        params[arr[0]]=arr[1]
    }
    let moreList = []
    for (let i = 0; i < params.pageSize; i++) {
        let newObject =Mock.mock({
                    'name': "@cname",
                    'character|1': ["业务人员", "审核人员", "风控经理", "管理员"],
                    'remark|5-20': '@cword',
                    'reason|1': ["需要进系统录入进件补充资料", "对进件进行风险审核", "对放款进行风险审核"],
                    'status|1': [0,1],
            })
        newObject.account=100000+i
        newObject.id=1+i
        moreList.push(newObject)
      }
    return {
        code: 200,
        success: true,
        message: "成功",
        data: {
            list:moreList,
            total:100,
        }
    }
})
//产品管理--全部产品   
Mock.mock(RegExp('localhost:8080/productList' + '.*'), 'get', (options) => {
    // const { password, username } = JSON.parse(req.body)
    let paramsData= options.url.split("?")[1].split("&")
    let params={}
    for(let i=0;i<paramsData.length;i++){
        let arr = paramsData[i].split("=")
        params[arr[0]]=arr[1]
    }
    let moreList = []
    for (let i = 0; i < params.pageSize; i++) {
        let newObject =Mock.mock({
                'type|1': ["汽车消费","房产消费","抵押贷款"],
                'name|1':["巴贝拉贷款","麦穗金融","日借款","爱猫借贷","樱花分期","小熊金融","借乐花","星星钱袋"],
                'limit|1': [100,200,300],
                'rate|1':[4.1,4.3,3.8,3.9,5,3] ,
                'number':Mock.Random.integer(30,200),
                'total': Mock.Random.integer(10000000,500000000),
                'average': Mock.Random.integer(10000000,250000000),
                'status|1':[1,2],
                'highest|1':[36,60,24,360],
                'date':Mock.Random.date()
            })
        newObject.id=1+i
        moreList.push(newObject)
      }
    return {
        code: 200,
        success: true,
        message: "成功",
        data: {
            list:moreList,
            total:100,
        }
    }
})