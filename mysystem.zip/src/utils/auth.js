function getToken(){
    return sessionStorage.getItem("token")
}

function getNickname(){
    return sessionStorage.getItem("nickname")
}

function setToken(token){
    sessionStorage.setItem("token",token)
}

function setNickname(nickname){
    sessionStorage.setItem("nickname",nickname)
}

function removeToken(){
    sessionStorage.removeItem("token")
}

function removeNickname(){
    sessionStorage.removeItem("nickname")
}

export {getToken,setToken,removeToken,getNickname,setNickname,removeNickname}